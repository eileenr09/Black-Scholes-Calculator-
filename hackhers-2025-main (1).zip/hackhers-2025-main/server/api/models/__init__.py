from .. import db

users_collectopn = db['users']
products_collection = db['products']
transactions_collection = db['transactions']
reviews_collection = db['reviews']
chats_collection = db['chats']